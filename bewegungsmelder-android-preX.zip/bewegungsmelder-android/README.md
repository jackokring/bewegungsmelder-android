Bewegungsmelder
===============

This App provides information on alternative events every day in Hamburg, Germany.

<a href="https://f-droid.org/repository/browse/?fdid=de.arnefeil.bewegungsmelder" target="_blank">
<img src="https://f-droid.org/badge/get-it-on.png" alt="Get it on F-Droid" height="90"/></a>
<a href="https://play.google.com/store/apps/details?id=de.arnefeil.bewegungsmelder&hl=fr" target="_blank">
<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" alt="Get it on Google Play" height="90"/></a>
